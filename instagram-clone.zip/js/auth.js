
function login() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  auth.signInWithEmailAndPassword(email, password)
    .then(() => {
      alert("Giriş başarılı!");
      window.location = "home.html";
    })
    .catch(error => alert(error.message));
}

function signup() {
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;

  auth.createUserWithEmailAndPassword(email, password)
    .then(() => {
      alert("Kayıt başarılı!");
      window.location = "index.html";
    })
    .catch(error => alert(error.message));
}

function resetPassword() {
  const email = document.getElementById("reset-email").value;
  auth.sendPasswordResetEmail(email)
    .then(() => alert("Şifre sıfırlama maili gönderildi!"))
    .catch(error => alert(error.message));
}
